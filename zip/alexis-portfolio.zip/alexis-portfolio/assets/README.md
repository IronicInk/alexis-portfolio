# Assets

Drop your project files here:

- **`resume.pdf`** — referenced by the "Download Resume" button in the Contact section
- **`favicon.ico`** — uncomment the `<link rel="icon">` line in `index.html` after adding
- **Project screenshots** — replace the Unsplash URLs in `index.html` with local paths like `assets/eatxplore-hero.jpg`

Recommended image sizes:
- Card thumbnails: 1000×750px (4:3)
- Case study banners: 2000×1125px (16:9)
- Hero avatar (if replacing the initials): 200×200px square
